import java.awt.*;
import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import Status;
import TabbedPanel;

public class SourceViewer extends Panel {
    Status status;
    TextArea viewer;
    Hashtable files;
    FileInfo currentFile;
    static final String spaces = "        ";
    boolean useNetConn;
    TabbedPanel tabPanel;

    public SourceViewer(boolean useNetConn, Status status) {
        this.useNetConn = useNetConn;
	this.status = status;
 	setLayout(new BorderLayout(0,0));

	viewer = new TextArea(12, 80);
	add("Center", viewer);
	viewer.setEditable(false);
	viewer.setFont(GetParams.getFont("tracer.sourcefont", Font.PLAIN, "Courier", 12));
	files = new Hashtable(20);

	//resize(600, 400);
	//setTitle("Source code browser");
	//show();
    }

  
    public void setTabPanel(TabbedPanel tabPanel) {
        this.tabPanel = tabPanel;
    }

    public void reset() {
	viewer.setText("");
	currentFile = null;
        files.clear();
    }

    public void showSelection() {
	System.err.println("Selection:" + viewer.getSelectedText());
    }

    public void showSourceLocation(Connection conn, String filename, int r, int c) {
      //setCursor(Frame.WAIT_CURSOR);			
	getToolkit().sync();
	if (filename != null && readFile(conn, filename)) {
	    markPosition(r-1, c);
	    //System.err.println("Marking line " + r + " col " + c + "\n");
	    //showSelection();
	}
	//setCursor(Frame.DEFAULT_CURSOR);			
	getToolkit().sync();
    }

    public void noSourceLocation() {
	viewer.setText("");
	currentFile = null;
	//setTitle("No source reference available.");
    }

    public String replaceTabs(String s) {
	int i, j;
	for (i = 0; i < s.length();) {
	    if (s.charAt(i) == '\t') {
		j = 8 - (i % 8);
		try {
		    s = s.substring(0, i) + 
		        spaces.substring(0, j) +		
		        s.substring(i+1);
		} catch (StringIndexOutOfBoundsException e) {
		    fail(e, "replaceTabs: bad args.");
		}
		i += j;
	    } else
		i++;
	}
	return s;
    }

  DataInputStream findSourceFile(String filename) {
    DataInputStream file;
    String dirs[] = {"/grp/fp/nhcdbg/hsruntime/", 
		     "/grp/fp/nhcdbg/hsruntime/mini-prelude/",
		     "/grp/fp/nhcdbg/hsruntime/boxes/"};
    for (int i = 0; i < dirs.length; i++) {
      try {
	file = new DataInputStream(new FileInputStream(dirs[i]+filename));
	return file;
      } catch (FileNotFoundException e) {
      }
    }
    System.err.println("findSourceFile: Couldn't find " + filename);
    return null;
  }

    public boolean readFile(Connection conn, String filename) {
	DataInputStream file;

	if ((currentFile = (FileInfo)files.get(filename)) != null) {
	    viewer.setText(currentFile.contents);
	    return true;
	}
	status.setText("Loading " + filename);
	    if (useNetConn) {
	        conn.out.println("F");
	        conn.out.println(filename);
	        file = conn.in;
	    } else {
	      file = findSourceFile(filename);
	    }
	    FileInfo fi = new FileInfo();
	    String line;

	    fi.lines = new Vector(50, 50);
	    fi.contents = "";
	    viewer.setText("");

	    try {
		int chars = 0;
		while ((line = file.readLine()) != null && !line.equals("<EOF>")) {
		    int i;
		    line = replaceTabs(line);
		    fi.contents = fi.contents + line + "\n";
		    fi.lines.addElement(new Integer(chars));
		    chars += line.length()+1;
		}
		viewer.setText(fi.contents);
		//setTitle(filename);
	    } catch (EOFException e) {}
	    catch (IOException e) {
	      fail(e, "io error reading source code file.");
	    }
	    currentFile = fi;
	    files.put(filename, fi);	      
	status.setText("");
	return true;
    }

    public void markPosition(int r, int c) {
        Integer i = (Integer)currentFile.lines.elementAt(r);
	viewer.select(i.intValue() + c-1, i.intValue() + c);
	tabPanel.select("Source code");
    }

    public static void fail(Exception e, String msg) {
        System.err.println(msg + ": " +  e);
        System.exit(1);
    }

}

class FileInfo {
  Vector lines;
  String contents;

  public FileInfo() {
  }
}
