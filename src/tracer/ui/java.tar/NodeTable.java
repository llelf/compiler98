import java.awt.*;
import java.util.Vector;

public class NodeTable {
    Vector nt;
    int currentSize = 0;

    public NodeTable() {
        nt = new Vector(50, 1000);
	nt.addElement(null); 
    }

    public void setNodeAt(EDTNode obj, int refnr) {
        try {
	  if (refnr > currentSize) {
	    for (int i = currentSize+1; i <= refnr; i++)
	      nt.addElement(null); 
	    currentSize = refnr;
	  }
	  nt.setElementAt(obj, refnr);
	} catch (ArrayIndexOutOfBoundsException e) {
	  System.err.println("NodeTable.setNodeAt: bad node index\n" + e);
	  System.exit(-1);
	}      
    }

    public EDTNode nodeAt(int refnr) {
        try {
	    return (EDTNode)nt.elementAt(refnr);
	} catch (ArrayIndexOutOfBoundsException e) {
	    System.err.println("NodeTable.nodeAt: bad node index\n" + e);
	    System.exit(-1);
	}        
	return null;
    }
}


