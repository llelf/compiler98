import java.awt.*;
import java.util.Vector;

public abstract class EDTStructuredNode extends EDTNode {
    Vector args;
    boolean contracted = false;

    public void contract() {
	contracted = !contracted;
    }

    public void setArgs(Vector args) {
	this.args = args;	
    }

  //    public boolean isInfix() {
  //        return (args != null && !(args.isEmpty()) && 
  //		args.elementAt(0) instanceof IdName &&
  //		((IdName)args.elementAt(0)).infix &&
  //		!((IdName)args.elementAt(0)).equals("[]"));
  //    }
  
    public boolean needParens(EDTStructuredNode node, int index) {
        if (parent == null)
	    return false;
        EDTNode con = (EDTNode)node.args.elementAt(0);
        return (!(con.tuple ||
		  con instanceof IdName &&
		  index == 2 &&
		  (((IdName)con).name.equals(":") ||
		   ((IdName)con).name.equals("."))));
    }
    
    public Object inside(UI ui, int x, int y, int x0, int y0) {
	int i, w;
	int cx;
	int spacew = ui.normalfm.charWidth(' ');
	EDTNode arg;
	String s;
	boolean isInfix = ((EDTNode)args.elementAt(0)).infix;
	boolean isTuple = ((EDTNode)args.elementAt(0)).tuple;
	boolean paren = needParens(parent, index) || isTuple;

	if (contracted) {
	    return (x >= x0 && x <= x0+width ? this : null);
	}

	if (x >= x0 && x <= x0+width) {
	    if (args.isEmpty())
		return this;

	    cx = x0;
	    if (paren)
	      cx += ui.normalfm.charWidth('(');
	    if (x <= cx)
	      return this;

	    if (isTuple) {
	        int commaspacew = spacew + ui.normalfm.charWidth(',');
	        for (i = 1; i < args.size(); i++) {
		    if (i > 1) {
		        cx += commaspacew;
		    }
		    if (x < cx) return this;
		    arg = (EDTNode)args.elementAt(i);
		    if (x <= cx+arg.width)
		      return arg.inside(ui, x, y, cx, y0);
		    cx += arg.width;		    
		}		
	    } else if (isInfix && args.size() == 3) {
		arg = (EDTNode)args.elementAt(1);
		if (x <= cx+arg.width)
		    return arg.inside(ui, x, y, cx, y0);
		cx += arg.width+spacew;
		if (x < cx) return this;
		arg = (EDTNode)args.elementAt(0);
		if (x <= cx+arg.width)
		    return arg.inside(ui, x, y, cx, y0);
		cx += arg.width+spacew;
		if (x < cx) return this;
		arg = (EDTNode)args.elementAt(2);
		if (x <= cx+arg.width)
		    return arg.inside(ui, x, y, cx, y0);
	    } else {
		for (i = 0; i < args.size(); i++) {
		    arg = (EDTNode)args.elementAt(i);
		    if (i > 0) {
		      if (x <= cx+spacew) return this;
		      cx += spacew;
		    }
		    w = arg.width;
		    if (x <= cx+w)
			return arg.inside(ui, x, y, cx, y0);
	            cx += w;
	   	}
	    }
	    return this;
	} else
	    return null;
    }

    public int paint_contracted(Graphics g, UI ui, int x0, int y0) {
	width = ui.normalfm.charWidth('m');
	int w = width * 5 / 6;
	this.x0 = x0;
	g.setColor(color);
	
	int baseline = y0 + ui.normalfm.getHeight();
	int topline = baseline - ui.normalfm.getAscent()*5/6;

	g.drawLine(x0-ui.dx, baseline-ui.dy, x0+w/3-ui.dx, baseline-ui.dy);
	g.drawLine(x0+w*2/3-ui.dx, baseline-ui.dy, x0+w-ui.dx, baseline-ui.dy);
	g.drawLine(x0-ui.dx, topline-ui.dy, x0+w/3-ui.dx, topline-ui.dy);
	g.drawLine(x0+w*2/3-ui.dx, topline-ui.dy, x0+w-ui.dx, topline-ui.dy);
	g.drawLine(x0-ui.dx, baseline-1-ui.dy, x0+w/3-ui.dx, baseline-1-ui.dy);
	g.drawLine(x0+w*2/3-ui.dx, baseline-1-ui.dy, x0+w-ui.dx, baseline-1-ui.dy);
	g.drawLine(x0-ui.dx, topline+1-ui.dy, x0+w/3-ui.dx, topline+1-ui.dy);
	g.drawLine(x0+w*2/3-ui.dx, topline+1-ui.dy, x0+w-ui.dx, topline+1-ui.dy);

	g.drawLine(x0-ui.dx, baseline-ui.dy, x0-ui.dx, baseline - (baseline - topline)/3-ui.dy);
	g.drawLine(x0+w-ui.dx, baseline-ui.dy, x0+w-ui.dx, baseline - (baseline - topline)/3-ui.dy);
	g.drawLine(x0-ui.dx, topline-ui.dy, x0-ui.dx, topline + (baseline - topline)/3-ui.dy);
	g.drawLine(x0+w-ui.dx, topline-ui.dy, x0+w-ui.dx, topline + (baseline - topline)/3-ui.dy);
	g.drawLine(x0+1-ui.dx, baseline-ui.dy, x0+1-ui.dx, baseline - (baseline - topline)/3-ui.dy);
	g.drawLine(x0+w-1-ui.dx, baseline-ui.dy, x0+w-1-ui.dx, baseline - (baseline - topline)/3-ui.dy);
	g.drawLine(x0+1-ui.dx, topline-ui.dy, x0+1-ui.dx, topline + (baseline - topline)/3-ui.dy);

//	g.drawLine(x0+2-ui.dx, (baseline+topline)/2-ui.dy, x0+w-2-ui.dx,(baseline+topline)/2-ui.dy);
//	g.drawLine(x0+2-ui.dx, (baseline+topline)/2-1-ui.dy, x0+w-2-ui.dx,(baseline+topline)/2-1-ui.dy);

//	g.drawLine(x0+w/2-ui.dx, baseline-2-ui.dy, x0+w/2-ui.dx,topline+2-ui.dy);
//	g.drawLine(x0+w/2+1-ui.dx, baseline-2-ui.dy, x0+w/2+1-ui.dx,topline+2-ui.dy);

	underline(g, ui, x0, y0, w);

	return width;
    }

    public int paint(Graphics g, UI ui, int x0, int y0, int refnr, int trefnr) {
	int spacew = ui.normalfm.charWidth(' ');
	EDTNode arg;
	int i, x;
	boolean isInfix = ((EDTNode)args.elementAt(0)).infix;
	boolean isTuple = ((EDTNode)args.elementAt(0)).tuple;
	boolean paren = needParens(parent, index) || isTuple;

	this.x0 = x0;
	color = Color.black;
	if (this.trefnr >= 0)
	  if (refnr == this.refnr) {
	    color = Color.blue;
	  } else if (trefnr == this.trefnr)
	    color = Color.red;

	g.setFont(ui.normalfont);
	
	if (contracted) {
	    return paint_contracted(g, ui, x0, y0);
	}

	x = x0;
	if (paren) {
	    g.setColor(color);
	    g.drawString("(", x0-ui.dx, y0-ui.dy+ui.normalfm.getHeight());
	    x += ui.normalfm.charWidth('(');
	}
	if (isTuple) {
	    for (i = 1; i < args.size(); i++) {
	        if (i > 1) {
		    g.setColor(color);
		    g.drawString(", ", x-ui.dx, 
				 y0-ui.dy+ui.normalfm.getHeight());
		    x += ui.normalfm.stringWidth(", ");
		}
		arg = (EDTNode)args.elementAt(i);
		x += arg.paint(g, ui, x, y0, refnr, trefnr);
	    }
	} else if (isInfix && args.size() == 3) {
	    String name = ((IdName)args.elementAt(0)).name;
	    arg = (EDTNode)args.elementAt(1);
	    x += arg.paint(g, ui, x, y0, refnr, trefnr) + spacew;	    
	    arg = (EDTNode)args.elementAt(0);
	    x += arg.paint(g, ui, x, y0, refnr, trefnr) + spacew;	    
	    arg = (EDTNode)args.elementAt(2);
	    x += arg.paint(g, ui, x, y0, refnr, trefnr);	    
	} else {
	    arg = (EDTNode)args.elementAt(0);
	    x += arg.paint(g, ui, x, y0, refnr, trefnr);
	    for (i = 1; i < args.size(); i++) {
	        arg = (EDTNode)args.elementAt(i);
		x += spacew + arg.paint(g, ui, x+spacew, y0, refnr, trefnr);
	    }
	}
	width = x-x0;
	if (paren) {
	    g.setColor(color);
	    g.drawString(")", x-ui.dx, y0-ui.dy+ui.normalfm.getHeight());
	    width += ui.normalfm.charWidth(')');
	}

	underline(g, ui, x0, y0, width);
	if (this.refnr == trefnr) {
	  g.setColor(Color.white);
	  g.setXORMode(Color.yellow);
	  g.fillRect(x0-ui.dx, y0-ui.dy+ui.normalfm.getDescent(), 
		     width, ui.normalfm.getHeight());
	  g.setPaintMode();
	  g.setColor(Color.black);
	}
	return width;
    }
}
