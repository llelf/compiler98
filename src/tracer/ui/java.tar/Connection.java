import java.io.*;
import java.net.*;
import java.awt.*;
import java.util.*;

public class Connection {
  String host;
  int port;
  String error;
  Socket server;
  protected String pushBacked = null;
  protected String line = null;
  DataInputStream in;
  PrintStream out;

  public Connection(String host, int port) {
    server = null;
    error = null;
    this.host = host;
    this.port = port;
    try {
      server = new Socket(host, port);
    }
    catch (IOException e) { 
      error = "Cannot connect to the server. Please try later.";
      return;
    }
    try { 
      in = new DataInputStream(server.getInputStream());
      out = new PrintStream(server.getOutputStream(), true);
    }
    catch (IOException e) {
      try { 
	server.close(); 
      } catch (IOException e2) {}
      error = "Cannot open input/output streams to the server. Please try later.";
      return;
    }
  }
    
  public Connection(String expr) {
    in = new DataInputStream(new StringBufferInputStream(expr));
    out = null;
  }

  public void close() {
    try { 
      if (in != null)
	in.close();
      if (out != null)
	out.close();
      if (server != null)
	server.close();
    } catch (IOException e) {
      System.err.println("Couldn't close socket!\n" + e);
    }
  }

  public void pushBack(String tok) {
    pushBacked = tok;	
  }

  public String rest() {
    if (pushBacked != null)
      return pushBacked+line;
    else
      return line;
  }

  public String nextToken() {
    String result;
    if (pushBacked != null) {
      result = pushBacked;
      pushBacked = null;
      return result;
    }
    for (;;) {
      if (line == null || line.length() == 0) {
	try {
	  //System.err.println("Waiting for line...");
	  line = in.readLine();
	  //System.err.println(line);
	} 
	catch (IOException e) {
	  // Should do something more sensible here...
	  System.err.println("tokenizer: Cannot read: " + e);
	  System.exit(-1);
	}
	if (line == null) {
	  System.err.println("Connection.nextToken: couldn't read");
	  //try { Thread.sleep(1000); }
	  //catch (InterruptedException e) {}
	  System.exit(-1);
	}
      }
      int len = line.length();
      int pos = 0, np;
      while (pos < len) {
	switch (line.charAt(pos)) {
	case '(':
	  result = "(";
	  line = line.substring(pos+1);
	  return result;
	case ')':
	  result = ")";
	  line = line.substring(pos+1);
	  return result;
	case '\'':
	  np = pos+1;
	  while (np < len && line.charAt(np) != '\'')
	    np++;
	  result = line.substring(pos, np+1);
	  line = line.substring(np+1);
	  return result;
	case '"':
	  np = pos+1;
	  while (np < len && line.charAt(np) != '"' || 
		 (line.charAt(np) == '"' && np > 0 && line.charAt(np-1) == '\\'))
	    np++;
	  result = line.substring(pos+1, np);
	  line = line.substring(np+1);
	  return result;
	case ' ':
	case '\n':
	case '\t':
	  pos++;
	  break;
	default:
	  np = pos;
	  while (np < len && "() ".indexOf(line.charAt(np)) < 0)
	    np++;
	  result = line.substring(pos, np);
	  line = line.substring(np);
	  return result;
	}
      }
      if (pos >= len)
	line = null;
    }
  }
}
