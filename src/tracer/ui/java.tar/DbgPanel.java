import java.awt.*;
import java.applet.*;
import java.util.Vector;
import java.io.*;
import EDTParser;
import Connection;
import SourceViewer;
import Status;

public class DbgPanel extends Applet /* implements Runnable */ {
    Frame parent;
    Thread DbgInterface;
    CanvasPanel canvas;
    SourceViewer viewer = null;
    TextArea source;
    Scrollbar hbar, vbar;
    Status status;
    TextArea msgArea;
    Color mbgc, bgc, fgc, lc;
    Trace trace;
    EDTNode lastNode = null;
    EDTNode selectedNode = null;
    public static final int START_X = 0;
    public static final int START_Y = 0;
    Image offscreen;
    Dimension offscreensize;
    Graphics offgraphics;
    int canvas_width, canvas_height;
    int tree_height = 1, tree_width = 1;
    Connection serverConnection;
    UI ui;
    NodeTable nodeTable;
    Dimension extents;

  //    public DbgPanel(Frame parent) {
    public DbgPanel(SourceViewer viewer, Status status) {
	super();

	this.viewer = viewer;
	this.status = status;

	setBackground(Color.white);

	canvas = new CanvasPanel(this);
	canvas.setBackground(getBackground());

	nodeTable = new NodeTable();

	ui = new UI();
	ui.normalfont = GetParams.getFont("tracer.tracefont", Font.PLAIN, "Helvetica", 20);
	ui.boldfont = ui.normalfont;
        ui.normalfm = getFontMetrics(ui.normalfont);	
        ui.boldfm = getFontMetrics(ui.boldfont);	

	hbar = new Scrollbar(Scrollbar.HORIZONTAL);
	hbar.setLineIncrement(ui.normalfm.charWidth('x'));
	vbar = new Scrollbar(Scrollbar.VERTICAL);
	vbar.setLineIncrement(ui.normalfm.getHeight());

	Panel p = new Panel();
	p.setBackground(getBackground());
	p.setLayout(new BorderLayout(0,0));
	p.add("Center", canvas);
	p.add("South", hbar);
	p.add("East", vbar);

	//status = new Status("Not connected");
	
	msgArea = new TextArea(6, 50);

	this.setLayout(new BorderLayout(0,0));
	this.add("Center", p);
	//this.add("South", status);

	bgc = Color.white;
	fgc = Color.red;
	lc = Color.black;
	mbgc = Color.cyan;
	// setBackground(Color.lightGray);

	trace = null;
    }

    public void connected() {
      EDTParser parser = new EDTParser(serverConnection, nodeTable);
      trace = parser.parseTrace(null);
      trace.color = Color.black;
      repaint();
    }

    public boolean mouseMove(Event evt, int x, int y) {
	if (trace == null)
	    return false;
	Object obj = trace.inside(ui, x+ui.dx, y+ui.dy, 
			          START_X, START_Y);
	
	if (obj == null) {	
	    if (lastNode != null) {
		lastNode.color = Color.black;
		lastNode = null;
		repaint();
	    }
	} else {
	    if (obj != lastNode) {
		if  (lastNode != null)
		    lastNode.color = Color.black;
		if (obj instanceof EDTNode) {
		    ((EDTNode)obj).color = Color.blue;
	    	    lastNode = (EDTNode)obj;
		} else if (obj instanceof Trace) {
	    	    lastNode = null;
		}
	    	repaint();
	    }
	}
	return true;
    }

    public boolean mouseDown(Event evt, int x, int y) {
	String path;
	Trace t;
	if (trace == null)
	    return false;

	Object obj = trace.inside(ui, x+ui.dx, y+ui.dy, START_X, START_Y);
		
	if (obj != null && obj instanceof Trace) {
	    status.setText("Expanding");
	    status.waitCursor();
	    t = (Trace)obj;
	    selectedNode = ((TraceTree)t.trees.elementAt(t.trees.size()-1)).node;
	    if (selectedNode.trefnr == 0) {
	        status.setText("The selected component has no trace");
	    } else {
	        serverConnection.out.println("Gn 5");
		serverConnection.out.println(selectedNode.trefnr);
		EDTParser parser = new EDTParser(serverConnection, nodeTable);
		parser.parseTraceTree(t);
		status.setText("");
	    }
	    status.normalCursor();
	} else if (obj != null && obj instanceof EDTNode) {
	  selectedNode = (EDTNode)obj;
	    if ((evt.modifiers & Event.META_MASK) != 0 &&
		(evt.modifiers & Event.SHIFT_MASK) != 0) {	// Shift-right click
	        if (selectedNode instanceof IdName) {
		    IdName name = (IdName)selectedNode;
		    SourceRef sr = new SourceRef(name.module, new Integer(name.defpos));
		    if (sr.col > 0) {
		        status.waitCursor();
			viewer.showSourceLocation(serverConnection, sr.file, sr.line, sr.col);
			status.normalCursor();
		    } else {
		        status.setText("Selected component has no source code definition");
		    }
		}
	    } else if ((evt.modifiers & Event.META_MASK) != 0) {	// Right click
	        SourceRef sr = selectedNode.sr;
		if (sr != null && sr.file != null) {
		    status.waitCursor();
		    viewer.showSourceLocation(serverConnection, sr.file, sr.line, sr.col);
		    status.normalCursor();
		} else {
		    status.setText("Selected component has no source reference");
		}
	    } else if ((evt.modifiers & Event.ALT_MASK) != 0 &&
		       (evt.modifiers & Event.SHIFT_MASK) != 0) { // Shift-middle click
	        if (selectedNode instanceof HString)
		    ((HString)selectedNode).consify();
		else
		    if (!HString.tryStringify(selectedNode))
		        status.setText("Selected component is not a string");
		repaint();
	    } else if ((evt.modifiers & Event.ALT_MASK) != 0) {	// Middle click
		if (selectedNode instanceof CutOffTree) { // Expand it
		    CutOffTree cot = (CutOffTree)selectedNode;
		    status.setText("Expanding");
		    status.waitCursor();
		    serverConnection.out.println("R 5");
		    serverConnection.out.println(selectedNode.refnr + " X");
		    EDTParser parser = new EDTParser(serverConnection, nodeTable);
		    EDTNode n = parser.parseEDTNode(cot.parent, cot.tree, cot.index);
		    try {
		        ((EDTStructuredNode)cot.parent).args.setElementAt(n, cot.index);
		    } catch (ArrayIndexOutOfBoundsException e) {
		        System.err.println("parent index bad: " +  e);
			System.exit(1);
		    }
		    status.setText("");
		    status.normalCursor();
		} else {
		    if (obj instanceof EDTStructuredNode) {
		    	((EDTStructuredNode)obj).contract();
		    }
		}
	    } else if ((evt.modifiers & Event.SHIFT_MASK) != 0) { // Shift-left click
	      System.err.println(selectedNode.show());
	    } else {						// Left click
		if (selectedNode.trace != null) {
		    selectedNode.trace.hidden = !selectedNode.trace.hidden;
		} else if ((t = selectedNode.tree.inTrace(selectedNode.trefnr)) != null) {
		    selectedNode.setTrace(t);
		    status.setText("");
		} else {
		  //		    if (selectedNode instanceof Pruned) {
		  //		        status.setText("Pruned nodes have no trace");
		  //			return true;
		  //		    }
		    status.setText("Expanding");
		    status.waitCursor();
		    if (selectedNode instanceof CutOffTree) {
		        CutOffTree cot = (CutOffTree)selectedNode;
			serverConnection.out.println("R 5");
			serverConnection.out.println(selectedNode.refnr + " X");
			EDTParser parser = new EDTParser(serverConnection, nodeTable);
			EDTNode n = parser.parseEDTNode(cot.parent, cot.tree, cot.index);
			try {
			    cot.parent.args.setElementAt(n, cot.index);
			} catch (ArrayIndexOutOfBoundsException e) {
			    System.err.println("parent index bad: " +  e);
			    System.exit(1);
			    status.setText("");
			}
		    } else {
		        if (selectedNode.trefnr == 0) {
			    status.setText("The selected component has no trace");
			} else {
			    serverConnection.out.println("Gn 5");
			    serverConnection.out.println(selectedNode.trefnr);
			    EDTParser parser = new EDTParser(serverConnection, nodeTable);
			    t = parser.parseTrace(selectedNode.tree);
			    selectedNode.setTrace(t);
			    selectedNode.tree.addTrace(t);
			    status.setText("");
			}
		    }
		}
		//System.err.println(selectedNode.trace.trees.size());
		status.normalCursor();
		repaint();
	    }
	}
	return true;
    }

    public /* synchronized */ void paint(Graphics g) {
      Dimension d = size();
      if (false)
	System.err.println("paint");
      if ((offscreen == null) || (d.width != offscreensize.width) || 
	  (d.height != offscreensize.height)) {
	offscreen = createImage(d.width, d.height);
	if (offscreen == null) {
	  System.err.println("Cannot allocate offscreen buffer of size "+
			     d.width + "x" + d.height + ".");
	  return;
	  /* System.exit(-1); */
	}
	offscreensize = d;
	offgraphics = offscreen.getGraphics();
	offgraphics.setFont(ui.normalfont);
      }
      offgraphics.setColor(getBackground());
      offgraphics.fillRect(0, 0, d.width, d.height);
      int refnr, trefnr;
      if (lastNode != null) {
	refnr = lastNode.refnr;
	trefnr = lastNode.trefnr;
      } else {
	refnr = -1;
	trefnr = -1;
      }
      if (trace != null) {
	extents = trace.paint(offgraphics, ui, START_X, START_Y, refnr, trefnr);
	if (extents.height != tree_height) {
	  tree_height = extents.height;
	  int canvas_rows = canvas.size().height / ui.normalfm.getHeight();
	  int vbar_size = tree_height / ui.normalfm.getHeight();// - canvas_rows; 
	  if (vbar_size < 0)
	    vbar_size = 0;
	  int vbar_value = vbar.getValue() >= vbar_size ? 0 : vbar.getValue();
	  ui.dy = vbar_value*vbar.getLineIncrement()+0; //4;
	  vbar.setValues(vbar_value, canvas_rows, 0, vbar_size);
	}
	//System.err.println("extwidth = " + extents.width + "  treewidth = " + tree_width);
	if (extents.width != tree_width) {
	  tree_width = extents.width;
	  int canvas_cols = tree_width / ui.normalfm.charWidth('x');
	  int hbar_size = tree_width; // - canvas_cols; //  / ui.normalfm.getHeight() - canvas_cols; 
	  if (hbar_size < 0)
	    hbar_size = 0;
	  int hbar_value = hbar.getValue() >= hbar_size ? 0 : hbar.getValue();
	  ui.dx = hbar_value;
	  hbar.setValues(hbar_value, canvas_cols, 0, hbar_size);
	  //System.err.println("hbar_value = "  + hbar_value + "  canvas_cols = " + canvas_cols + "  hbar_size = " + hbar_size);
	}
	if (false)
	    System.err.println("offscreen = " + offscreen);
      }
      canvas.getGraphics().drawImage(offscreen, 0, 0, null);
    }

    public boolean handleEvent(Event e) {
	if (e.target == hbar) {
	    switch (e.id) {
		case Event.SCROLL_LINE_UP:
		case Event.SCROLL_LINE_DOWN:
		case Event.SCROLL_PAGE_UP:
		case Event.SCROLL_PAGE_DOWN:
		case Event.SCROLL_ABSOLUTE:
		    ui.dx = ((Integer)e.arg).intValue()/* *ui.normalfm.charWidth('n')*/;
		    //System.err.println("Scrollbar(h) dx = " + ui.dx);
		    break;
	    }
	    repaint();
	    //this.update(canvas.getGraphics());
	    return true;
	} else if (e.target == vbar) {
	    switch (e.id) {
		case Event.SCROLL_LINE_UP:
		case Event.SCROLL_LINE_DOWN:
		case Event.SCROLL_PAGE_UP:
		case Event.SCROLL_PAGE_DOWN:
		case Event.SCROLL_ABSOLUTE:
		    ui.dy = ((Integer)e.arg).intValue()*vbar.getLineIncrement()+4;
		    break;
	    }
	    repaint();
	    //this.update(canvas.getGraphics());
	    return true;
	} else if (e.target == canvas && e.id == Event.MOUSE_ENTER) {
	    canvas.requestFocus();
	} else if (e.target == canvas && e.id == Event.MOUSE_UP) {
	    repaint();
	    return true;
	} else if (e.id == Event.KEY_ACTION) {
	  //System.err.println("Key pressed");
	  if (trace != null) {
	    switch (e.key) {
		case Event.UP:
		    ui.dy -= vbar.getLineIncrement();		    
		    //		    System.err.println("dy = " + ui.dy + "  vbar.y = " + vbar.getValue());
		    break;
		case Event.DOWN:		 
		    ui.dy += vbar.getLineIncrement();
		    //		    System.err.println("dy = " + ui.dy + "  vbar.y = " + vbar.getValue());
		    break;
		case Event.PGUP:
		    ui.dy -= vbar.getPageIncrement();
		    break;
		case Event.PGDN:
		    ui.dy += vbar.getPageIncrement();
		    break;
	        case Event.RIGHT:
		    ui.dx += hbar.getLineIncrement();
		    break;
	        case Event.LEFT:
		    ui.dx -= hbar.getLineIncrement();
		    break;
		case Event.HOME:
		    ui.dx = 0;
		    break;
		case Event.END:
		    ui.dx = ((extents.width - hbar.getPageIncrement()+
			      hbar.getLineIncrement()-1)/
			     hbar.getLineIncrement())*hbar.getLineIncrement();
		    break;
	        default:
		    break;
	    }
	    if (ui.dy > extents.height - vbar.getPageIncrement()+
		vbar.getLineIncrement()-1)
	      ui.dy = ((extents.height - vbar.getPageIncrement()+
			vbar.getLineIncrement()-1)/
		       vbar.getLineIncrement())*vbar.getLineIncrement();
	    if (ui.dy < 0) 
	      ui.dy = 0;
	    vbar.setValue(ui.dy / vbar.getLineIncrement());
	    if (ui.dx > extents.width - hbar.getPageIncrement() + 
		hbar.getLineIncrement()-1)
	      ui.dx = ((extents.width - hbar.getPageIncrement()+
			hbar.getLineIncrement()-1)/
		       hbar.getLineIncrement())*hbar.getLineIncrement();
	    if (ui.dx < 0) 
	      ui.dx = 0;
	    hbar.setValue(ui.dx / hbar.getLineIncrement());
	    repaint();
	  }
	}		    

	return super.handleEvent(e);
    }

    public synchronized void reshape(int x, int y, int width, int height) {
	if (canvas.getGraphics() != null) {
	    super.reshape(x, y, width, height);
	    Dimension hbar_size = hbar.size();
	    Dimension vbar_size = vbar.size();
	    canvas_width = width - vbar_size.width;
	    canvas_height = height - hbar_size.height;
	    if (false)
		System.err.println(
		    "x = " + x +
		    "\ny = " + y +
		    "\nwidth = " + width +
		    "\nheight = " + height +
		    "\nhbar_size.width = " + hbar_size.width +
		    "\nhbar_size.height = " + hbar_size.height +
		    "\nvbar_size.width = " + vbar_size.width +
		    "\nvbar_size.height = " + vbar_size.height +
		    "\ncanvas_height = " + canvas_height +
		    "\ncanvas_width = " + canvas_width);

	    if (canvas_width > 0 && canvas_height > 0) {
		hbar.setValues(ui.dx, canvas_width, 0, tree_width);
		if (trace == null)
		    vbar.setValues(ui.dy, canvas_height, 0, 1);
		else
		    vbar.setValues(ui.dy, canvas_height, 0, 
				   (tree_height - canvas_height) / ui.normalfm.getHeight());
		hbar.setPageIncrement(canvas_width);
		vbar.setPageIncrement(canvas_height);
		if (false)
		System.err.println("canvas= " + canvas + "\nthis = " + this +
				    "\ncanvas-graphics = " + canvas.getGraphics());
		this.update(canvas.getGraphics());
	    }
	}
    }	
  
    public Dimension preferredSize() {
        return new Dimension(600, 300);
    }

}


