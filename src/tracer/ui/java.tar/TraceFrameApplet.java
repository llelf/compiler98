import java.awt.*;
import java.applet.*;
import java.io.*;
import Connection;
import DbgPanel;
import OutputPanel;
import TabbedPanel;
import Status;

public class TraceFrameApplet extends Applet {
 
  public TraceFrameApplet(String host, int port) {
    super();
    TraceFrame traceFrame = new TraceFrame(host,
					   port,
					   "Haskell Tracer", 
					   "Jan Sparud",
					   "Version -0.01 alpha");
    traceFrame.resize(600, 700);
    traceFrame.show();
    this.start();
  }
  
  public void run() {
  }
  
  public void init() {
  }
  
  static void usage() {
    System.err.println("Usage: java TraceFrameApplet port");
    System.exit(1);
  }
  
  public static void main(String[] argv) {
    int port = 0;
    String host = null;

    if (argv.length < 1)
      usage();
    try { port = Integer.parseInt(argv[0]); }
    catch (NumberFormatException e) { 
      usage();
      }
    if (argv.length == 2)
      host = argv[1];

    new TraceFrameApplet(host, port);
  }
}

class TraceFrame extends Frame {
  MenuBar menuBar;
  
  Menu fileMenu;
  Menu editMenu;
  Menu viewMenu;
  Menu helpMenu;
  
  MenuItem exitItem;
  
  MenuItem copyItem;
  MenuItem cutItem;
  MenuItem pasteItem;

  MenuItem aboutItem;
  
  int port;
  String host;
  String appTitle;
  String appAuthor;
  String appVersion;

  DbgPanel dbgPanel;
  OutputPanel outputPanel;
  SourceViewer viewer;
  Status status;
  TabbedPanel tabPanel;
  Button connect;
  Button disconnect;
  Connection serverConnection;
  public TraceFrame(String host,
		    int port, 
		    String appTitle, 
		    String appAuthor, 
		    String appVersion) {

    this.port = port;
    this.host = host == null ? "localhost" : host;
    this.appTitle = appTitle;
    this.appAuthor = appAuthor;
    this.appVersion = appVersion;
	
    menuBar = new MenuBar(); setMenuBar(menuBar);
	
    menuBar.setFont(new Font("Helvetica", Font.PLAIN, 14));
	
    fileMenu = new Menu("File"); menuBar.add(fileMenu);
    editMenu = new Menu("Edit"); menuBar.add(editMenu);
    viewMenu = new Menu("View"); menuBar.add(viewMenu);
    helpMenu = new Menu("Help"); menuBar.add(helpMenu);
	
    exitItem = new MenuItem("Exit"); fileMenu.add(exitItem);
	
    copyItem = new MenuItem("Copy"); editMenu.add(copyItem);
    cutItem = new MenuItem("Cut"); editMenu.add(cutItem);
    pasteItem = new MenuItem("Paste"); editMenu.add(pasteItem);
	
    copyItem.disable();
    cutItem.disable();
    pasteItem.disable();
	
    aboutItem = new MenuItem("About"); helpMenu.add(aboutItem);
    menuBar.setHelpMenu(helpMenu);
	
    setTitle(appTitle);

    status = new Status("Not connected");
    viewer = new SourceViewer(true, status);
    dbgPanel = new DbgPanel(viewer, status);
    outputPanel = new OutputPanel(status);
    outputPanel.setDbgPanel(dbgPanel);
    connect = new Button("Connect");
    disconnect = new Button("Disconnect");

    Label dbgLabel = new Label("Trace window", Label.CENTER);
    dbgLabel.setBackground(Color.red);
    dbgLabel.setForeground(Color.white);
    dbgLabel.setFont(new Font("Helvetica", Font.PLAIN, 20));
        
    Panel pb = new Panel();
    pb.setLayout(new FlowLayout());
    pb.add(connect);
    pb.add(disconnect);

    TabbedPanel tp = new TabbedPanel();
    tp.addItem("Trace browser", dbgPanel);

    Panel p1 = new Panel();
    p1.setLayout(new BorderLayout());
    //     p1.add("North", dbgLabel);
    p1.add("Center", tp);
    p1.add("South", status);

    tabPanel = new TabbedPanel();
    tabPanel.addItem("Program output", outputPanel);
    tabPanel.addItem("Source code", viewer);
    viewer.setTabPanel(tabPanel);
    outputPanel.setTabPanel(tabPanel);

    this.setLayout(new BorderLayout());
    this.add("North", pb);
    this.add("Center", p1);
    this.add("South", tabPanel);

  }
  
  public void stop() {
    if (serverConnection != null) {
      outputPanel.disconnected();      
      serverConnection = null;
      viewer.reset();
    }
  }

  public boolean handleEvent(Event evt) {
    if(evt.target instanceof MenuItem) {
      if(evt.target == exitItem || 
	 evt.id == Event.WINDOW_DESTROY) {
	if (serverConnection != null)
	  outputPanel.disconnected();
	System.exit(0);
	return true;
      } else if(evt.target == aboutItem) {
	AboutDialog about = new AboutDialog(this, appTitle, appAuthor, appVersion);
	return true;
      }
    }
    if (evt.id == Event.ACTION_EVENT) {
      if (evt.target == connect) {
	if (serverConnection == null) {
	  status.setText("Connecting to server. Please wait.");
	  serverConnection = new Connection(host, port);
	  if (serverConnection.error == null) {
	    outputPanel.connected(serverConnection);      
	  } else {
	    status.setText(serverConnection.error);
	    serverConnection = null;
	  }
	} else {
	  status.setText("Already connected");
	}
	return true;
      } else if (evt.target == disconnect) {
	if (serverConnection == null) {
	  status.setText("Not connected");
	} else {
	  outputPanel.disconnected();      
	  serverConnection = null;
	  viewer.reset();
	}
	return true;
      }
    }
    return super.handleEvent(evt);
  }
  
  public void destroy() {
    dispose();
    System.exit(0);
  }
}

class AboutDialog extends Dialog {

	public AboutDialog(Frame parent, String title, String author, String version) {
		super(parent, title, true);

		int i;
		int width, height;

		setLayout(new BorderLayout());

		Panel titlePanel = new Panel();
		Panel buttonPanel = new Panel();

		FontMetrics m = getFontMetrics(getFont());

		width = m.stringWidth(title);
		if((i=m.stringWidth(author)) > width) width = i;
		if((i=m.stringWidth(version)) > width) width = i;
	
		height = m.getHeight();

		resize((width*3)/2, height*10);

		titlePanel.setLayout(new GridLayout(3,1));
		titlePanel.add("North",new Label(title,Label.CENTER));
		titlePanel.add("Center",new Label(author,Label.CENTER));
		titlePanel.add("South",new Label(version,Label.CENTER));

		buttonPanel.setLayout(new BorderLayout());
		buttonPanel.add("Center", new Button("OK"));

		add("Center", titlePanel);
		add("South", buttonPanel);

		show();
	}

	public boolean handleEvent(Event e) {

		if(e.target instanceof Button) {
			dispose();
			return true;
		}
		return false;
	}
}
