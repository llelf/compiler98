import java.awt.*;
import java.util.Vector;

public class Trace extends Object {
    TraceTree parent;
    Vector trees;
    Color color;
    int x0, y0, height;
    boolean hidden;
    int index;
    public static final int INDENT = 20;
    public static final int RADIUS = (INDENT-4)/2;

    public Trace(TraceTree parent/*, int index*/) {
	this.parent = parent;
	//this.index = index;
	trees = new Vector(3, 3);
	hidden = false;
    }

    public Object inside(UI ui, int x, int y, int x0, int y0) {
	int h;
	int cy = y0;
	Object result;
	Trace trace;
	
	if (x >= x0 && x <= x0+2*RADIUS && 
	    y >= y0+height-ui.normalfm.getHeight() /*&& y <= cy-ui.normalfm.getHeight()*/)
	    return this;
	for (int i = 0; i < trees.size(); i++) {
	    TraceTree tree = (TraceTree)trees.elementAt(i);	    
	    if (y < cy+tree.height)
	        return tree.inside(ui, x, y, x0+INDENT, cy);
	    cy += tree.height;
	}
	return null;
    }

    public Dimension paint(Graphics g, UI ui, int x, int y, int refnr, int trefnr) {
	int i;
	int cy = y;
	int maxw = 0;
	TraceTree tree = null;
	Dimension d;

	x0 = x;
	y0 = y;
	for (i = 0; i < trees.size(); i++) {
	    tree = (TraceTree)trees.elementAt(i);
	    d = tree.paint(g, ui, x + INDENT, cy, refnr, trefnr);
	    if (d.width > maxw)
	        maxw = d.width;
	    cy += d.height;
	}
	height = cy - y0;
	g.setColor(color);
	g.fillArc(x-ui.dx+RADIUS/2, y0-ui.dy+ui.normalfm.getHeight()/2,
		  RADIUS, RADIUS, 0, 360);
	g.drawLine(x-ui.dx+RADIUS, cy-ui.dy, x-ui.dx+RADIUS, 
		   y0-ui.dy+ui.normalfm.getHeight()/2);
	if (tree != null && tree.node.trefnr == 0) {
	    g.drawLine(x-ui.dx, cy-ui.dy-1, x-ui.dx+2*RADIUS, cy-ui.dy-1);
	    g.drawLine(x-ui.dx, cy-ui.dy, x-ui.dx+2*RADIUS, cy-ui.dy);
	} else {
	    int xPoints[] = {x-ui.dx, x-ui.dx+2*RADIUS, x-ui.dx+RADIUS};
	    int yPoints[] = {cy-ui.dy-ui.normalfm.getHeight()/2,
			     cy-ui.dy-ui.normalfm.getHeight()/2,
			     cy-ui.dy};
	    g.fillPolygon(xPoints, yPoints, 3);
	}
	return new Dimension(maxw, height);
    }
}

	//	if (node == null)
	//	    return null;

	//System.err.println("trace.inside: x="+x+" y="+y+" x0="+x0+" y0="+y0+" height="+height);
// 	if (y >= y0 && y <= y0+height)
// 	    if (x >= x0 + HINDENT) {
// 	        Trace trace = this;
// 		while (trace != null) {
// 		    cy += ui.normalfm.getHeight();
// 		    if (y <= cy) {
// 		        if ((result = trace.node.inside(ui, x, y, x0+HINDENT, y0)) != null)
// 			    return result;
// 		    } else {
// 		      for (i = 0; i < traces.size(); i++) {
// 		        trace = (Trace)traces.elementAt(i);
// 			h = trace.height;
// 			if (!trace.hidden && y <= cy+h)
// 			    if ((result = trace.inside(ui, x, y, x0 + HINDENT, cy)) != null)
// 			      return result;
// 			if (!trace.hidden)
// 			    cy += h;
// 		    }
// 		}
// 	    }
// 	    if (next == null) {
// 	        return this;
// 	    } else {
// 	        if ((result = next.inside(ui, x, y, x0, cy)) != null)
// 		    return result;
// 		else
// 		    return this;
// 	    }
// 	} else {
// 	  return null;
// 	}
//	return null;
