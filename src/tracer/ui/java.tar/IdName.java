import java.awt.*;

class IdName extends EDTNode {
    String module;
    String name;
    int defpos;

    public IdName(EDTStructuredNode parent, TraceTree tree, int index) {
	this.parent = parent;
	this.tree = tree;
	this.index = index;
	this.trace = null;
    }

    public IdName(EDTStructuredNode parent, TraceTree tree, int index, SourceRef sr, int refnr, String module, String name, int defpos) {
        if (name.equals(",,"))
	  name = ",";
	this.parent = parent;
	this.tree = tree;
	this.index = index;
	this.sr = sr;
	this.refnr = refnr;
	this.trace = null;
	
	this.module = module;
	this.name = name;
	this.defpos = defpos;

	int c = this.name.charAt(0);
	infix = !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
		  (c >= '0' && c <= '9') || c == '(' || c == '[' || 
		  c == '\'' || c == ',' || this.name == "\\");
	tuple = c == ',';
    }

    public EDTNode spawn(EDTStructuredNode parent, TraceTree tree, int index) {
        IdName idName = new IdName(parent, tree, index);
        //System.err.println("spawning " + this + "(" + this.name + ") into " + idName);
	idName.sr = sr;
	idName.refnr = refnr;
	idName.trefnr = trefnr;
	idName.name = name;
	idName.module = module;
	idName.defpos = defpos;
	idName.infix = infix;
	idName.tuple = tuple;
	return idName;
    }

    public Object inside(UI ui, int x, int y, int x0, int y0) {
	if (x >= x0 && x <= x0+width) {
	    return this;
	} else {
	    return null;
	}
    }

    public int paint(Graphics g, UI ui, int x0, int y0, int refnr, int trefnr) {
      boolean parenthesize = false;


      color = Color.black;
      if (this.trefnr >= 0) // Don't bother with cut-off-trees
	  if (refnr == this.refnr) {
	      color = Color.blue;
	  } else if (trefnr == this.trefnr)
	      color = Color.red;
      g.setColor(color);

      if (false) { // Non-clickable
	g.setFont(ui.boldfont);
      }
      FontMetrics fm = g.getFontMetrics();
      int x = x0;
      if (infix && (index > 0 || (parent != null && parent.args.size() != 3))){
	  parenthesize = true;
	  g.drawString("(", x-ui.dx, y0-ui.dy+fm.getHeight());
	  x += fm.stringWidth("(");
      }
      g.drawString(name, x-ui.dx, y0-ui.dy+fm.getHeight());
      x += fm.stringWidth(name);
      if (parenthesize) {
	  g.drawString(")", x-ui.dx, y0-ui.dy+fm.getHeight());
	  x += fm.stringWidth(")");
      }
      width = x-x0;
      g.setFont(ui.normalfont);
      underline(g, ui, x0, y0, width);
      if (this.refnr == trefnr) {
	g.setColor(Color.white);
	g.setXORMode(Color.yellow);
	g.fillRect(x0-ui.dx, y0-ui.dy+ui.normalfm.getDescent(), width, ui.normalfm.getHeight());
	g.setPaintMode();
	g.setColor(Color.black);
      }
      return width;
    }
}

