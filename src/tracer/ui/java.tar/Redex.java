import java.awt.*;
import java.util.Vector;

public class Redex extends EDTStructuredNode {
    public Redex(EDTStructuredNode parent, TraceTree tree, int index) {
	this.parent = parent;
	this.tree = tree;
	this.index = index;
	this.trace = null;
	args = new Vector(3, 10);
    }

    public Redex(EDTStructuredNode parent, TraceTree tree, int index, SourceRef sr, int refnr) {
	this.parent = parent;
	this.tree = tree;
	this.index = index;
	this.sr = sr;
	this.refnr = refnr;
	trace = null;
	args = new Vector(3, 10);
    }

    public EDTNode spawn(EDTStructuredNode parent, TraceTree tree, int index) {
        Redex redex = new Redex(parent, tree, index);
	redex.sr = sr;
	redex.refnr = refnr;
	redex.trefnr = trefnr;
	for (int i = 0; i < args.size(); i++)
	  redex.args.addElement(((EDTNode)args.elementAt(i)).spawn(redex, tree, i));
	return redex;
    }
}
