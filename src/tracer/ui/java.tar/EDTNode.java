import java.awt.*;

public abstract class EDTNode extends Object {
    EDTStructuredNode parent;
    TraceTree tree;
    Trace trace;
    SourceRef sr;
    Color color = Color.black;
    int refnr;
    int trefnr;
    int index;
    int width;
    int x0;
    boolean infix = false, tuple = false;

    abstract public Object inside(UI ui, int x, int y, int x0, int y0);
    abstract public int paint(Graphics g, UI ui, int x0_, int y0, int refnr, int trefnr);
    abstract public EDTNode spawn(EDTStructuredNode parent, TraceTree tree, int index);

    public void setTrace(Trace trace) {
	this.trace = trace;
    }

    public void setTRefNr(int trefnr) {
	this.trefnr = trefnr;
    }

    public void expand() {
	if (trace == null) {
	    // Ask the debugger for info
	    // For now, just fake some info
	} else {
	    trace.hidden = !trace.hidden;
	}
    }

    public void underline(Graphics g, UI ui, int x, int y, int width) {
	int i;
	if (trace != null) {
	    int ly = y + ui.normalfm.getHeight() + 2;
	    if (trace.hidden) {
		g.setColor(Color.black);
		for (i = x; i < x+width-3; i += 6) {
		    g.drawLine(i-ui.dx, ly-ui.dy, i+3-ui.dx, ly-ui.dy);
		    g.drawLine(i-ui.dx, ly+1-ui.dy, i+3-ui.dx, ly+1-ui.dy);
		}
	    } else {
		g.setColor(trace.color);
		g.drawLine(x-ui.dx, ly-ui.dy, x+width-ui.dx, ly-ui.dy);
		g.drawLine(x-ui.dx, ly+1-ui.dy, x+width-ui.dx, ly+1-ui.dy);
	    }
	}	
    }

    public String show() {
      return 
	"" + this + "\n" +
	"refnr  = " + refnr + "\n" +
	"trefnr = " + trefnr + "\n";
    }
}
