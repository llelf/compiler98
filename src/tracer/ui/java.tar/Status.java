import java.awt.*;

class Status extends TextField {
    Toolkit tk;
    
    Status(String text) {
      super(text);
      tk = Toolkit.getDefaultToolkit();
      setEditable(false);
      tk.sync();
    }

    public void setText(String newText) {
        super.setText(newText);
	tk.sync();
    }

    public void normalCursor() {
      //tk.setCursor(Frame.DEFAULT_CURSOR);			
      tk.sync();
    }

    public void waitCursor() {
      //parent.setCursor(Frame.WAIT_CURSOR);
      tk.sync();
    }
}
