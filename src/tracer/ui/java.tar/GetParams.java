import java.awt.Font;

public class GetParams {
  public static Font getFont(String param, int deftype, String deffont, int defsize) {
    String parfont = System.getProperty(param);
    if (parfont == null)
      return new Font(deffont, deftype, defsize);
    int colonpos = parfont.indexOf(':');
    if (colonpos < 0) {
      System.err.println("GetParams.getFont: Bad " + param + ": " + parfont);
      System.exit(-1);
    }
    String fontname = parfont.substring(0, colonpos-1);
    String sizestr = parfont.substring(colonpos+1);
    try {
      Integer size = new Integer(sizestr);
	  return new Font(fontname, deftype, size.intValue());
    } catch (NumberFormatException e) {
      System.err.println("GetParams.getFont: bad font size for " + param 
			 + ": " + sizestr);
      System.exit(-1);
    }    
    return null;
  }
}
