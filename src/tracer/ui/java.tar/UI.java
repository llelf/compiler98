import java.awt.FontMetrics;
import java.awt.Font;

public class UI extends Object {
    FontMetrics normalfm;
    FontMetrics boldfm;
    Font normalfont;
    Font boldfont;
    int dx, dy;

    public UI() {
	dx = 0;
	dy = 0;
    }
}

