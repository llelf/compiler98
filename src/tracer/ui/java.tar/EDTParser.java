import java.awt.*;
import java.util.Vector;
import Connection;
import Output;

public class EDTParser {
    Connection conn;
    NodeTable nodeTable;

    public EDTParser(Connection conn, NodeTable nodeTable) {
        this.nodeTable = nodeTable;
	this.conn = conn;
    }

    public Output parseOutput() {
        Output output = new Output();
        int chars = parseNr();
	for (int i = 0; i < chars; i++) {
	    output.addChar((char)parseNr(), parseNr());
	}
	return output;
    }

    public Trace parseTrace(TraceTree ptree) {
        Trace trace = new Trace(ptree);
	TraceTree tree = parseTraceTree(trace);
	
// 	if (parent != null) {
// 	    parent.setTrace(trace);
// 	    parent.ptrace.addTrace(trace);
// 	}
	return trace;
    }

    public TraceTree parseTraceTree(Trace parent) {
        TraceTree tree = new TraceTree(parent);
	EDTNode node = parseEDTNode((EDTStructuredNode)null, tree, -1);	    
	tree.setNode(node);
	return tree;
    }

    public void expect(int ch) {
	String t = conn.nextToken();
	//System.err.println("expect: read " + t);
	
	if (t.charAt(0) != ch) {
	    System.err.println("expect: expected '" + (char)ch + "', but got " + t);
	    System.err.println("input: " + conn.rest());
	    System.exit(-1);
	}
    }

    public Vector parseRedexes(EDTStructuredNode parent) {
	Vector result = new Vector(3, 10);
	int index = 0;
	
	expect('(');

	String t = conn.nextToken();
	//System.err.println("parseRedexes: read " + t);
	while (t.charAt(0) != ')') {
	    conn.pushBack(t);
	    result.addElement(parseEDTNode(parent, parent.tree, index++));
	    t = conn.nextToken();
	    //System.err.println("parseRedexes(2): read " + t);
	}
	return result;
    }

    public String parseIdent() {
	String t = conn.nextToken();
	//System.err.println("parseIdent: read " + t);
	return t;
    }

    public SourceRef parseSR() {
	String modname = conn.nextToken();
	switch (modname.charAt(0)) {
	    case '*':
		return new SourceRef((String)null, new Integer(0));
	    default:
		String rcs = conn.nextToken();
		try {
	    	    Integer rc = new Integer(rcs);
	    	    return new SourceRef(modname, rc);
		} catch (NumberFormatException e) {
	    	    System.err.println("parseSR: expected a number, got " + 
					rcs + "\n" + e);
		    System.err.println("input: " + conn.rest());
	    	    System.exit(-1);
		} catch (StringIndexOutOfBoundsException e) {
	    	    System.err.println("parseSR: bad string index\n" + e);
	    	    System.exit(-1);
		}
		break;
	}
	return null;
    }

    public EDTNode parseEDTNode(EDTStructuredNode parent, TraceTree tree, int index) {
	SourceRef srcref;
	int refnr, trefnr;
	String t = conn.nextToken();
	//System.err.println("parseEDTNode: ptrace= " + ptrace);

	switch (t.charAt(0)) {
	    case '(':
		// Start of a redex or a producer
		EDTNode result = null;
		Trace trace;
		t = conn.nextToken();
		switch (t.charAt(0)) {
		    case 'N':
			refnr = parseNr();
			srcref = parseSR();
			String module = parseIdent();
			String constr = parseIdent();
			int defpos = parseNr();
			result = new IdName(parent, tree, index, srcref, refnr, module, constr, defpos);			
			trefnr = parseNr();
			result.setTRefNr(trefnr);
			nodeTable.setNodeAt(result, refnr);
			break;
		    case 'A':
			refnr = parseNr();
			srcref = parseSR();
			result = new Redex(parent, tree, index, srcref, refnr);
			nodeTable.setNodeAt(result, refnr);
			((Redex)result).setArgs(parseRedexes((Redex)result));
			trefnr = parseNr();
			result.setTRefNr(trefnr);
			break;
		    case 'R':
			refnr = parseNr();		      
			result = nodeTable.nodeAt(refnr).spawn(parent, tree, index);
		        break;
		    case 'C':
		        refnr = parseNr();		      
		        result = new CutOffTree(parent, tree, index, refnr);
			break;
		    case 'B':
		        refnr = parseNr();		      
		        trefnr = parseNr();		      
		        result = new Bottom(parent, tree, index, refnr, trefnr);
			nodeTable.setNodeAt(result, refnr);
			break;
		}
		expect(')');
		return result;
	    case '_': // The root node
		System.err.println("ParseEDT: hmm, Root...");
		System.exit(-1);
		//return null;
	    case 'P':
		return new Pruned(parent, tree, index);
	    default:
		System.err.println("ParseEDT: expected '(', 'C', or 'B', but got " + t);
		System.exit(-1);
        }
	return null;
    }

    public int parseNr() {
      String rcs = conn.nextToken();
      try {
	  Integer refnr = new Integer(rcs);
	  return refnr.intValue();
      } catch (NumberFormatException e) {
	  System.err.println("parseNR: expected a number, got " + 
			     rcs + "\n" + e);
	  System.err.println("input: " + conn.rest());
	  System.exit(-1);
      } catch (StringIndexOutOfBoundsException e) {
	  System.err.println("parseNR: expected a number, got " + 
			     rcs + "\n" + e);
		    System.err.println("input: " + conn.rest());
	  System.exit(-1);
      }
      return -1;
    }
}

