import java.awt.*;

public class CanvasPanel extends Panel {
  Panel parent;
  public CanvasPanel(Panel parent) {
      this.parent = parent;
  }

  public void paint(Graphics g) {
    parent.repaint();
  }
}
