import java.awt.*;
import java.applet.*;
import java.util.Vector;
import java.io.*;
import EDTParser;
import Connection;
import DbgPanel;
import Output;
import OutputPanel;
import TabbedPanel;

public class OutputPanel extends Applet {
    //  OutputFrame parent;
    Output output;
    DbgPanel dbgPanel;
    CanvasPanel canvas;
    Status status;
    TabbedPanel tabPanel;
    Connection serverConnection;
    Scrollbar hbar, vbar;
    Image offscreen;
    Dimension offscreensize;
    Graphics offgraphics;
    int canvas_width, canvas_height;
    int tree_height = 1, tree_width = 1;
    UI ui;
    public static final int START_X = 0;
    public static final int START_Y = 0;
    int refnr = 0;

    public OutputPanel(Status status) {
        this.status = status;
        setBackground(Color.white);
	canvas = new CanvasPanel(this);
        canvas.setBackground(getBackground());
	output = new Output();
	serverConnection = null; /*new Server(6706, this);*/
	ui = new UI();
	ui.normalfont = GetParams.getFont("tracer.outputfont", Font.PLAIN, "Courier", 20);
	ui.boldfont = ui.normalfont;
        ui.normalfm = getFontMetrics(ui.normalfont);	
        ui.boldfm = getFontMetrics(ui.boldfont);	
	hbar = new Scrollbar(Scrollbar.HORIZONTAL);
	hbar.setLineIncrement(ui.normalfm.charWidth('x'));
	vbar = new Scrollbar(Scrollbar.VERTICAL);
	vbar.setLineIncrement(ui.normalfm.getHeight());
	setLayout(new BorderLayout(0,0));
	add("Center", canvas);
	add("South", hbar);
	add("East", vbar);	
    }

    public void connected(Connection serverConnection) {
        this.serverConnection = serverConnection;
	output = null;
	dbgPanel.serverConnection = serverConnection;
	status.setText("Connected to server");
	String t = serverConnection.nextToken();
	if (t.equals("Error")) {
	    dbgPanel.connected();
	} else {
	    EDTParser parser = new EDTParser(serverConnection, dbgPanel.nodeTable);
	    output = parser.parseOutput();
	    tabPanel.select("Program output");
	    repaint();
	}
    }

    public void disconnected() {
        serverConnection.close();
	output = null;
	dbgPanel.serverConnection = null;
	dbgPanel.trace = null;
	status.setText("Disconnected");
	dbgPanel.repaint();
	repaint();
    }

    public void setDbgPanel(DbgPanel dbgPanel) {
        this.dbgPanel = dbgPanel;
	dbgPanel.serverConnection = serverConnection;
    }

    public void setTabPanel(TabbedPanel tabPanel) {
        this.tabPanel = tabPanel;
    }

    public /* synchronized */ void paint(Graphics g) {
      //System.err.println("Painting..."+output.lines.size());
      Dimension d = size();
      if (false)
	System.err.println("update");
      if ((offscreen == null) || (d.width != offscreensize.width) || 
	  (d.height != offscreensize.height)) {
	offscreen = createImage(d.width, d.height);
	if (offscreen == null) {
	  System.err.println("Cannot allocate offscreen buffer of size "+
			     d.width + "x" + d.height + ".");
	  return;
	  /* System.exit(-1); */
	}
	offscreensize = d;
	offgraphics = offscreen.getGraphics();
	offgraphics.setFont(ui.normalfont);
      }
      offgraphics.setColor(getBackground());
      offgraphics.fillRect(0, 0, d.width, d.height);
      if (output != null) {
	Dimension extents = output.paint(offgraphics, ui, START_X, START_Y, refnr);
	if (extents.height != tree_height) {
	  tree_height = extents.height;
	  int canvas_rows = canvas.size().height / ui.normalfm.getHeight();
	  int vbar_size = tree_height / ui.normalfm.getHeight() - canvas_rows; 
	  if (vbar_size < 0)
	    vbar_size = 0;
	  int vbar_value = vbar.getValue() >= vbar_size ? 0 : vbar.getValue();
	  ui.dy = vbar_value*vbar.getLineIncrement()+0; //4;
	  vbar.setValues(vbar_value, canvas_rows, 0, vbar_size);
	}
	if (extents.width != tree_width) {
	  tree_width = extents.width;
	  int canvas_cols = canvas.size().width; // / ui.normalfm.charWidth('n');
	  int hbar_size = tree_width - canvas_cols; //  / ui.normalfm.getHeight() - canvas_cols; 
	  if (hbar_size < 0)
	    hbar_size = 0;
	  int hbar_value = hbar.getValue() >= hbar_size ? 0 : hbar.getValue();
	  ui.dx = hbar_value;
	  hbar.setValues(hbar_value, canvas_cols, 0, hbar_size);
	}
	if (false)
	  System.err.println("offscreen = " + offscreen);
      }
      canvas.getGraphics().drawImage(offscreen, 0, 0, null);
    }

    public boolean mouseDown(Event evt, int x, int y) {
      	if (output == null)
	    return false;

	Object obj = output.inside(ui, x+ui.dx, y+ui.dy, START_X, START_Y);
	if (obj instanceof OutputChar) {
	    OutputChar oc = (OutputChar)obj;
	    serverConnection.out.println("Gn 5");
	    serverConnection.out.println(""+oc.refnr);
	    EDTParser parser = new EDTParser(serverConnection, dbgPanel.nodeTable);
	    dbgPanel.trace = parser.parseTrace(null);
	    dbgPanel.trace.color = Color.black;
	    dbgPanel.repaint();
	    return true;
	}
	return false;
    }

    public boolean mouseMove(Event evt, int x, int y) {
	if (output == null)
	    return false;
	Object obj = output.inside(ui, x+ui.dx, y+ui.dy, START_X, START_Y);
	
	if (obj == null) {	
	    refnr = -1;
	} else if (obj instanceof OutputChar) {
	    refnr = ((OutputChar)obj).refnr;
	}
	repaint();
	return true;
    }

    public boolean handleEvent(Event e) {
	if (e.target == hbar) {
	    switch (e.id) {
		case Event.SCROLL_LINE_UP:
		case Event.SCROLL_LINE_DOWN:
		case Event.SCROLL_PAGE_UP:
		case Event.SCROLL_PAGE_DOWN:
		case Event.SCROLL_ABSOLUTE:
		    ui.dx = ((Integer)e.arg).intValue()/* *ui.normalfm.charWidth('n')*/;
		    //System.err.println("Scrollbar(h) dx = " + ui.dx);
		    break;
	    }
	    repaint();
	    //this.update(canvas.getGraphics());
	    return true;
	} else if (e.target == vbar) {
	    switch (e.id) {
		case Event.SCROLL_LINE_UP:
		case Event.SCROLL_LINE_DOWN:
		case Event.SCROLL_PAGE_UP:
		case Event.SCROLL_PAGE_DOWN:
		case Event.SCROLL_ABSOLUTE:
		    ui.dy = ((Integer)e.arg).intValue()*vbar.getLineIncrement()+4;
		    break;
	    }
	    repaint();
	    //this.update(canvas.getGraphics());
	    return true;
	} else if (e.target == canvas && e.id == Event.MOUSE_UP) {
	    repaint();
	    return true;
	} else if (e.id == Event.KEY_PRESS) {
	    switch (e.key) {
		case Event.UP:
		    vbar.setValue(vbar.getValue()-1);
		case Event.DOWN:
		    vbar.setValue(vbar.getValue()+1);
		case Event.PGUP:
		    vbar.setValue(vbar.getValue()-vbar.getPageIncrement());
		case Event.PGDN:
		    vbar.setValue(vbar.getValue()+vbar.getPageIncrement());
		case Event.HOME:
		    vbar.setValue(vbar.getMinimum());
		case Event.END:
		    vbar.setValue(vbar.getMaximum()-vbar.getPageIncrement());
		    ui.dy = vbar.getValue()*vbar.getLineIncrement()+4;
		    repaint();
		    return true;
	        default:
		    break;
	    }
	}		    
//         if (e.target == server) {
// 	    switch (e.id) {
// 	        case Server.CONNECTED:
// 		    status.setText("Connected to debugger");
// 		    String t = server.connection.nextToken();
// 		    if (t.equals("Error")) {
// 		        dbgPanel.handleEvent(new Event(server, Server.CONNECTED, null));


// 		    } else {
// 		        EDTParser parser = new EDTParser(server.connection, dbgPanel.nodeTable);
// 			output = parser.parseOutput();
// 			repaint();
// 		    }
// 		    break;
// 	    }
// 	    return true;
// 	}
// 	repaint();
	return super.handleEvent(e);
    }

    public Dimension preferredSize() {
        return new Dimension(600, 160);
    }
}
