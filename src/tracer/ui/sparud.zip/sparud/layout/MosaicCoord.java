///////////////////////////////////////////////////////////////
//
// MosaicCoord.java 1.0 97/02/05 Robert Buff buff@cs.nyu.edu
//
// Copyright (c) 1997 Robert Buff. All Rights Reserved.
//
// You may use, copy, modify, and distribute this software
// for NON-COMMERCIAL purposes and without fee provided that
// this copyright notice appears in all copies. If you would
// like to use this software for COMMERCIAL purposes, contact
// the author and we will work something out.
//
// It would also be nice to give credit to the author in the
// Help/About dialog window of any application that uses this
// software.
//
///////////////////////////////////////////////////////////////

package sparud.layout;

///////////////////////////////////////////////////////////////
//
//   M o s a i c C o o r d
//
///////////////////////////////////////////////////////////////

final class MosaicCoord extends Object implements Cloneable
{
  protected int m_col;
  protected int m_row;

  //
  //   M o s a i c C o o r d
  //

  public MosaicCoord( int col, int row )
  {
    m_col = col;
    m_row = row;
  }

  //
  //   t o S t r i n g
  //

  public String toString()
  {
    return "(" + m_col + "," + m_row + ")";
  }

  //
  //   c l o n e
  //

  public Object clone()
  {
    return new MosaicCoord( m_col, m_row );
  }
}
